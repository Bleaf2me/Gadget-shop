webpackHotUpdate_N_E("pages/index",{

/***/ "./pages/modal/modal.tsx":
/*!*******************************!*\
  !*** ./pages/modal/modal.tsx ***!
  \*******************************/
/*! exports provided: ModalWindow */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ModalWindow", function() { return ModalWindow; });
/* harmony import */ var _babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _md_modules_gadget_shop_cart_cart__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @md-modules/gadget-shop/cart/cart */ "./modules/gadget-shop/cart/cart.tsx");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_modal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-modal */ "./node_modules/react-modal/lib/index.js");
/* harmony import */ var react_modal__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_modal__WEBPACK_IMPORTED_MODULE_3__);


var _jsxFileName = "C:\\Users\\\u0418\u0433\u043E\u0440\u044C\\Desktop\\cultum-fe-starter-kit\\cultum-fe-starter-kit\\pages\\modal\\modal.tsx",
    _s = $RefreshSig$();

var __jsx = react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement;



var customStyles = {
  content: {
    top: '50%',
    left: '50%',
    right: 'auto',
    bottom: 'auto',
    marginRight: '-50%',
    transform: 'translate(-50%, -50%)'
  }
}; // Make sure to bind modal to your appElement (http://reactcommunity.org/react-modal/accessibility/)

react_modal__WEBPACK_IMPORTED_MODULE_3___default.a.setAppElement('#__next');
function ModalWindow() {
  _s();

  var subtitle;

  var _React$useState = react__WEBPACK_IMPORTED_MODULE_2___default.a.useState(false),
      _React$useState2 = Object(_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__["default"])(_React$useState, 2),
      modalIsOpen = _React$useState2[0],
      setIsOpen = _React$useState2[1];

  function openModal() {
    setIsOpen(true);
  }

  function afterOpenModal() {
    // references are now sync'd and can be accessed.
    subtitle.style.color = '#f00';
  }

  function closeModal() {
    setIsOpen(false);
  }

  return __jsx("div", {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 37,
      columnNumber: 5
    }
  }, __jsx("button", {
    onClick: openModal,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 38,
      columnNumber: 7
    }
  }, "Cart"), __jsx("span", {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 38,
      columnNumber: 48
    }
  }, "1 item"), __jsx(react_modal__WEBPACK_IMPORTED_MODULE_3___default.a, {
    isOpen: modalIsOpen,
    onAfterOpen: afterOpenModal,
    onRequestClose: closeModal,
    style: customStyles,
    contentLabel: "Example Modal",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 39,
      columnNumber: 7
    }
  }, __jsx("h2", {
    ref: function ref(_subtitle) {
      return subtitle = _subtitle;
    },
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 46,
      columnNumber: 9
    }
  }, "Hello"), __jsx("button", {
    onClick: closeModal,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 47,
      columnNumber: 9
    }
  }, "close"), __jsx(_md_modules_gadget_shop_cart_cart__WEBPACK_IMPORTED_MODULE_1__["ShoppingCart"], {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 48,
      columnNumber: 9
    }
  })));
}

_s(ModalWindow, "EOxo+0MXKxyCdUCTWpcfchJ0gFI=");

_c = ModalWindow;

var _c;

$RefreshReg$(_c, "ModalWindow");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvbW9kYWwvbW9kYWwudHN4Il0sIm5hbWVzIjpbImN1c3RvbVN0eWxlcyIsImNvbnRlbnQiLCJ0b3AiLCJsZWZ0IiwicmlnaHQiLCJib3R0b20iLCJtYXJnaW5SaWdodCIsInRyYW5zZm9ybSIsIk1vZGFsIiwic2V0QXBwRWxlbWVudCIsIk1vZGFsV2luZG93Iiwic3VidGl0bGUiLCJSZWFjdCIsInVzZVN0YXRlIiwibW9kYWxJc09wZW4iLCJzZXRJc09wZW4iLCJvcGVuTW9kYWwiLCJhZnRlck9wZW5Nb2RhbCIsInN0eWxlIiwiY29sb3IiLCJjbG9zZU1vZGFsIiwiX3N1YnRpdGxlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFHQSxJQUFNQSxZQUFZLEdBQUc7QUFDbkJDLFNBQU8sRUFBRTtBQUNQQyxPQUFHLEVBQUUsS0FERTtBQUVQQyxRQUFJLEVBQUUsS0FGQztBQUdQQyxTQUFLLEVBQUUsTUFIQTtBQUlQQyxVQUFNLEVBQUUsTUFKRDtBQUtQQyxlQUFXLEVBQUUsTUFMTjtBQU1QQyxhQUFTLEVBQUU7QUFOSjtBQURVLENBQXJCLEMsQ0FXQTs7QUFDQUMsa0RBQUssQ0FBQ0MsYUFBTixDQUFvQixTQUFwQjtBQUVPLFNBQVNDLFdBQVQsR0FBdUI7QUFBQTs7QUFDNUIsTUFBSUMsUUFBSjs7QUFENEIsd0JBRUtDLDRDQUFLLENBQUNDLFFBQU4sQ0FBZSxLQUFmLENBRkw7QUFBQTtBQUFBLE1BRXJCQyxXQUZxQjtBQUFBLE1BRVJDLFNBRlE7O0FBRzVCLFdBQVNDLFNBQVQsR0FBcUI7QUFDbkJELGFBQVMsQ0FBQyxJQUFELENBQVQ7QUFDRDs7QUFFRCxXQUFTRSxjQUFULEdBQTBCO0FBQ3hCO0FBQ0FOLFlBQVEsQ0FBQ08sS0FBVCxDQUFlQyxLQUFmLEdBQXVCLE1BQXZCO0FBQ0Q7O0FBRUQsV0FBU0MsVUFBVCxHQUFzQjtBQUNwQkwsYUFBUyxDQUFDLEtBQUQsQ0FBVDtBQUNEOztBQUVELFNBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUNFO0FBQVEsV0FBTyxFQUFFQyxTQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREYsRUFDMkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUQzQyxFQUVFLE1BQUMsa0RBQUQ7QUFDRSxVQUFNLEVBQUVGLFdBRFY7QUFFRSxlQUFXLEVBQUVHLGNBRmY7QUFHRSxrQkFBYyxFQUFFRyxVQUhsQjtBQUlFLFNBQUssRUFBRXBCLFlBSlQ7QUFLRSxnQkFBWSxFQUFDLGVBTGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQU9FO0FBQUksT0FBRyxFQUFFLGFBQUNxQixTQUFEO0FBQUEsYUFBZ0JWLFFBQVEsR0FBR1UsU0FBM0I7QUFBQSxLQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFQRixFQVFFO0FBQVEsV0FBTyxFQUFFRCxVQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUkYsRUFTRSxNQUFDLDhFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFURixDQUZGLENBREY7QUFpQkQ7O0dBakNlVixXOztLQUFBQSxXIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL2luZGV4LjMyMzNlNmU4YTNhNWNiNzJlMTBmLmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBTaG9wcGluZ0NhcnQgfSBmcm9tICdAbWQtbW9kdWxlcy9nYWRnZXQtc2hvcC9jYXJ0L2NhcnQnO1xyXG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgTW9kYWwgZnJvbSAncmVhY3QtbW9kYWwnO1xyXG5cclxuXHJcbmNvbnN0IGN1c3RvbVN0eWxlcyA9IHtcclxuICBjb250ZW50OiB7XHJcbiAgICB0b3A6ICc1MCUnLFxyXG4gICAgbGVmdDogJzUwJScsXHJcbiAgICByaWdodDogJ2F1dG8nLFxyXG4gICAgYm90dG9tOiAnYXV0bycsXHJcbiAgICBtYXJnaW5SaWdodDogJy01MCUnLFxyXG4gICAgdHJhbnNmb3JtOiAndHJhbnNsYXRlKC01MCUsIC01MCUpJ1xyXG4gIH1cclxufTtcclxuXHJcbi8vIE1ha2Ugc3VyZSB0byBiaW5kIG1vZGFsIHRvIHlvdXIgYXBwRWxlbWVudCAoaHR0cDovL3JlYWN0Y29tbXVuaXR5Lm9yZy9yZWFjdC1tb2RhbC9hY2Nlc3NpYmlsaXR5LylcclxuTW9kYWwuc2V0QXBwRWxlbWVudCgnI19fbmV4dCcpO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIE1vZGFsV2luZG93KCkge1xyXG4gIHZhciBzdWJ0aXRsZTogYW55O1xyXG4gIGNvbnN0IFttb2RhbElzT3Blbiwgc2V0SXNPcGVuXSA9IFJlYWN0LnVzZVN0YXRlKGZhbHNlKTtcclxuICBmdW5jdGlvbiBvcGVuTW9kYWwoKSB7XHJcbiAgICBzZXRJc09wZW4odHJ1ZSk7XHJcbiAgfVxyXG5cclxuICBmdW5jdGlvbiBhZnRlck9wZW5Nb2RhbCgpIHtcclxuICAgIC8vIHJlZmVyZW5jZXMgYXJlIG5vdyBzeW5jJ2QgYW5kIGNhbiBiZSBhY2Nlc3NlZC5cclxuICAgIHN1YnRpdGxlLnN0eWxlLmNvbG9yID0gJyNmMDAnO1xyXG4gIH1cclxuXHJcbiAgZnVuY3Rpb24gY2xvc2VNb2RhbCgpIHtcclxuICAgIHNldElzT3BlbihmYWxzZSk7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdj5cclxuICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtvcGVuTW9kYWx9PkNhcnQ8L2J1dHRvbj48c3Bhbj4xIGl0ZW08L3NwYW4+XHJcbiAgICAgIDxNb2RhbFxyXG4gICAgICAgIGlzT3Blbj17bW9kYWxJc09wZW59XHJcbiAgICAgICAgb25BZnRlck9wZW49e2FmdGVyT3Blbk1vZGFsfVxyXG4gICAgICAgIG9uUmVxdWVzdENsb3NlPXtjbG9zZU1vZGFsfVxyXG4gICAgICAgIHN0eWxlPXtjdXN0b21TdHlsZXN9XHJcbiAgICAgICAgY29udGVudExhYmVsPSdFeGFtcGxlIE1vZGFsJ1xyXG4gICAgICA+XHJcbiAgICAgICAgPGgyIHJlZj17KF9zdWJ0aXRsZSkgPT4gKHN1YnRpdGxlID0gX3N1YnRpdGxlKX0+SGVsbG88L2gyPlxyXG4gICAgICAgIDxidXR0b24gb25DbGljaz17Y2xvc2VNb2RhbH0+Y2xvc2U8L2J1dHRvbj5cclxuICAgICAgICA8U2hvcHBpbmdDYXJ0IC8+XHJcblxyXG4gICAgICA8L01vZGFsPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG5cclxuXHJcbiJdLCJzb3VyY2VSb290IjoiIn0=