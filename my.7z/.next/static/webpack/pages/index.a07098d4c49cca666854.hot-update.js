webpackHotUpdate_N_E("pages/index",{

/***/ "./modules/shared/components/ui/headers/main/index.tsx":
/*!*************************************************************!*\
  !*** ./modules/shared/components/ui/headers/main/index.tsx ***!
  \*************************************************************/
/*! exports provided: Header */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Header", function() { return Header; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _md_ui_menu_items_main__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @md-ui/menu-items/main */ "./modules/shared/components/ui/menu-items/main/index.tsx");
/* harmony import */ var _md_ui_logos_main__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @md-ui/logos/main */ "./modules/shared/components/ui/logos/main/index.tsx");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./constants */ "./modules/shared/components/ui/headers/main/constants.ts");
/* harmony import */ var _views__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./views */ "./modules/shared/components/ui/headers/main/views.ts");
/* harmony import */ var pages_modal_modal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! pages/modal/modal */ "./pages/modal/modal.tsx");
var _this = undefined,
    _jsxFileName = "C:\\Users\\\u0418\u0433\u043E\u0440\u044C\\Desktop\\cultum-fe-starter-kit\\cultum-fe-starter-kit\\modules\\shared\\components\\ui\\headers\\main\\index.tsx";

var __jsx = react__WEBPACK_IMPORTED_MODULE_0__["createElement"];
 // view components


 // constants

 // views




var Header = function Header() {
  return __jsx(_views__WEBPACK_IMPORTED_MODULE_4__["Wrapper"], {
    __self: _this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 5
    }
  }, __jsx(_views__WEBPACK_IMPORTED_MODULE_4__["IWrapper"], {
    __self: _this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 7
    }
  }, __jsx(_views__WEBPACK_IMPORTED_MODULE_4__["LWrapper"], {
    __self: _this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 15,
      columnNumber: 9
    }
  }, __jsx(_md_ui_logos_main__WEBPACK_IMPORTED_MODULE_2__["Logo"], {
    __self: _this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 16,
      columnNumber: 11
    }
  })), __jsx(_views__WEBPACK_IMPORTED_MODULE_4__["RWrapper"], {
    __self: _this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 18,
      columnNumber: 9
    }
  }, _constants__WEBPACK_IMPORTED_MODULE_3__["menuItems"].map(function (_ref) {
    var l = _ref.l,
        h = _ref.h;
    return __jsx(_md_ui_menu_items_main__WEBPACK_IMPORTED_MODULE_1__["MenuItem"], {
      key: l,
      href: h,
      label: l,
      __self: _this,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 20,
        columnNumber: 13
      }
    });
  }), __jsx(pages_modal_modal__WEBPACK_IMPORTED_MODULE_5__["ModalWindow"], {
    __self: _this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 22,
      columnNumber: 11
    }
  }))));
};

_c = Header;


var _c;

$RefreshReg$(_c, "Header");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../../../../node_modules/webpack/buildin/harmony-module.js */ "./node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vbW9kdWxlcy9zaGFyZWQvY29tcG9uZW50cy91aS9oZWFkZXJzL21haW4vaW5kZXgudHN4Il0sIm5hbWVzIjpbIkhlYWRlciIsIm1lbnVJdGVtcyIsIm1hcCIsImwiLCJoIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQUNBOztBQUNBO0NBRUE7O0NBRUE7O0FBQ0E7QUFDQTs7QUFFQSxJQUFNQSxNQUFNLEdBQUcsU0FBVEEsTUFBUyxHQUFNO0FBQ25CLFNBQ0UsTUFBQyw4Q0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQ0UsTUFBQywrQ0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQ0UsTUFBQywrQ0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQ0UsTUFBQyxzREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBREYsQ0FERixFQUlFLE1BQUMsK0NBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUNHQyxvREFBUyxDQUFDQyxHQUFWLENBQWM7QUFBQSxRQUFHQyxDQUFILFFBQUdBLENBQUg7QUFBQSxRQUFNQyxDQUFOLFFBQU1BLENBQU47QUFBQSxXQUNiLE1BQUMsK0RBQUQ7QUFBVSxTQUFHLEVBQUVELENBQWY7QUFBa0IsVUFBSSxFQUFFQyxDQUF4QjtBQUEyQixXQUFLLEVBQUVELENBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFEYTtBQUFBLEdBQWQsQ0FESCxFQUlFLE1BQUMsNkRBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUpGLENBSkYsQ0FERixDQURGO0FBZUQsQ0FoQkQ7O0tBQU1ILE07QUFrQk4iLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguYTA3MDk4ZDRjNDljY2E2NjY4NTQuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcclxuLy8gdmlldyBjb21wb25lbnRzXHJcbmltcG9ydCB7IE1lbnVJdGVtIH0gZnJvbSAnQG1kLXVpL21lbnUtaXRlbXMvbWFpbic7XHJcbmltcG9ydCB7IExvZ28gfSBmcm9tICdAbWQtdWkvbG9nb3MvbWFpbic7XHJcbi8vIGNvbnN0YW50c1xyXG5pbXBvcnQgeyBtZW51SXRlbXMgfSBmcm9tICcuL2NvbnN0YW50cyc7XHJcbi8vIHZpZXdzXHJcbmltcG9ydCB7IFdyYXBwZXIsIElXcmFwcGVyLCBMV3JhcHBlciwgUldyYXBwZXIgfSBmcm9tICcuL3ZpZXdzJztcclxuaW1wb3J0IHsgTW9kYWxXaW5kb3cgfSBmcm9tICdwYWdlcy9tb2RhbC9tb2RhbCc7XHJcblxyXG5jb25zdCBIZWFkZXIgPSAoKSA9PiB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxXcmFwcGVyPlxyXG4gICAgICA8SVdyYXBwZXI+XHJcbiAgICAgICAgPExXcmFwcGVyPlxyXG4gICAgICAgICAgPExvZ28gLz5cclxuICAgICAgICA8L0xXcmFwcGVyPlxyXG4gICAgICAgIDxSV3JhcHBlcj5cclxuICAgICAgICAgIHttZW51SXRlbXMubWFwKCh7IGwsIGggfSkgPT4gKFxyXG4gICAgICAgICAgICA8TWVudUl0ZW0ga2V5PXtsfSBocmVmPXtofSBsYWJlbD17bH0gLz5cclxuICAgICAgICAgICkpfVxyXG4gICAgICAgICAgPE1vZGFsV2luZG93IC8+XHJcbiAgICAgICAgPC9SV3JhcHBlcj5cclxuICAgICAgPC9JV3JhcHBlcj5cclxuICAgIDwvV3JhcHBlcj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IHsgSGVhZGVyIH07XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=