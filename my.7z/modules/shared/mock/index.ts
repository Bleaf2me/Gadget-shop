export interface Gadget {
  name: string;
  id: string;
  price: string;
  img: string;
}

export const allGadgets: Gadget[] = [
  // {
  //   name: 'Ben Kenobi',
  //   id: '1',
  //   hair_color: 'blond',
  //   skin_color: 'fair',
  //   gender: 'male',
  //   eye_color: 'blue',
  //   birth_year: '19BBY'
  // },
  {
    name: 'Laptop',
    id: '1',
    price: '950',
    img: 'fair',
  },
  {
    name: 'Headphones',
    id: '2',
    price: '120',
    img: 'fair',
  },
  {
    name: 'Tablet',
    id: '3',
    price: '500',
    img: 'fair',
  },
  {
    name: 'Mobile phone',
    id: '4',
    price: '600',
    img: 'fair',
  },
  {
    name: 'Camera',
    id: '5',
    price: '350',
    img: 'fair',
  },

];
