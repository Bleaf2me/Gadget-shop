export const menuItems = [{ l: 'Cart', h: '/cart' }];
