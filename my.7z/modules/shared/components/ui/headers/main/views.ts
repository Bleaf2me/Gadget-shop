import styled from 'styled-components';

export const Wrapper = styled.div`

`;

export const IWrapper = styled.div`

`;

export const LWrapper = styled.div`

`;

export const RWrapper = styled.div`

`;
