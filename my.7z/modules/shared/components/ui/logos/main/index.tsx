import * as React from 'react';
// components
import Link from 'next/link';

const Logo = () => (
  <Link href='/' passHref>
    <a>
      Logo
    </a>
  </Link>
);

export { Logo };
