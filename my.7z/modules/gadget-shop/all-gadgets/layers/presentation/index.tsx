import * as React from 'react';
// view components
import { ContentLoader } from '@md-ui/loaders/content-loader';
import { Card } from '@md-gs-all-gadgets/compoonents/card';
// context
import { AllGadgetsAPIContext } from '@md-gs-all-gadgets/layers/api/all-gadgets';
import { AllGadgetsBLContext } from '@md-gs-all-gadgets/layers/business';
// views
import { Wrapper } from './views';

const AllGadgetsPresentation = () => {
  const { isLoading } = React.useContext(AllGadgetsAPIContext);
  const { allGadgetsList } = React.useContext(AllGadgetsBLContext);

  return (
    <Wrapper>
      <ContentLoader isLoading={isLoading}>
        {allGadgetsList.map((gadget) => (
          <Card {...gadget} key={gadget.id} />
        ))}
      </ContentLoader>
    </Wrapper>
  );
};

export { AllGadgetsPresentation };
