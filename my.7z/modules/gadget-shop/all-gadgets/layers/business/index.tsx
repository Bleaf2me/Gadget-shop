import * as React from 'react';
// context
import { AllGadgetsAPIContext } from '@md-gs-all-gadgets/layers/api/all-gadgets';
// mock
import { Gadget } from '@md-modules/shared/mock';

interface Context {
  allGadgetsList: Pick<Gadget, 'id' | 'name'>[];
}

const AllGadgetsBLContext = React.createContext<Context>({
  allGadgetsList: []
});

const AllGadgetsBLContextProvider: React.FC = ({ children }) => {
  // add business logic here
  const { allGadgets } = React.useContext(AllGadgetsAPIContext);

  const allGadgetsList = React.useMemo<Pick<Gadget, 'id' | 'name'>[]>(() => {
    if (!allGadgets) {
      return [];
    }

    return allGadgets.map(({ id, name }) => ({
      name,
      id
    }));
  }, [typeof allGadgets === 'undefined']);

  return (
    <AllGadgetsBLContext.Provider
      value={{
        allGadgetsList
      }}
    >
      {children}
    </AllGadgetsBLContext.Provider>
  );
};

export { AllGadgetsBLContextProvider, AllGadgetsBLContext };
