import * as React from 'react';
import { AllGadgetsAPIContextProvider } from '@md-gs-all-gadgets/layers/api/all-gadgets';
import { AllGadgetsBLContextProvider } from '@md-gs-all-gadgets/layers/business';
import { AllGadgetsPresentation } from '@md-gs-all-gadgets/layers/presentation';

const AllGadgetsContainer = () => (
  <AllGadgetsAPIContextProvider>
    <AllGadgetsBLContextProvider>
      <AllGadgetsPresentation />
    </AllGadgetsBLContextProvider>
  </AllGadgetsAPIContextProvider>
);

export { AllGadgetsContainer };
