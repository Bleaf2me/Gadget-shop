import * as React from 'react';
// components
import Link from 'next/link';

interface Props {
  gId: string;
}

const GadgetLink: React.FC<Props> = ({ gId, children }) => (
  <Link href='/all-gadgets/[id]' as={`/all-gadgets/${gId}`}>
    <a>{children}</a>
  </Link>
);

export { GadgetLink };
