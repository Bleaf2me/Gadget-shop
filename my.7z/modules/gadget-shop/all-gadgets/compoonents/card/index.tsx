import * as React from 'react';
// views
import { CardWrapper, CardImgWrapper, CardImg, CardFooter, CardFooterTitle, ViewButton } from './views';
// view components
import { GadgetLink } from '../gadget-link';

interface Props {
  id: string;
  name: string;
}

const Card: React.FC<Props> = ({ id, name }) => (
  <CardWrapper key={id}>
    <CardImgWrapper>
      <CardImg src={'/'} alt={`${name}-${id}`} />
    </CardImgWrapper>
    <CardFooter>
      <GadgetLink gId={id}>
        <CardFooterTitle>{name}</CardFooterTitle>
      </GadgetLink>
      <GadgetLink gId={id}>
        <ViewButton>Details</ViewButton>
      </GadgetLink>
      <ViewButton>Add to cart</ViewButton>
    </CardFooter>
  </CardWrapper>
);

export { Card };
