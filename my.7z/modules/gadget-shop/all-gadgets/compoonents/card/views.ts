import styled from 'styled-components';

export const CardWrapper = styled.div`
  border-radius: 5px;
  overflow: hidden;
`;

export const CardImgWrapper = styled.div`
  // padding: 55% 0 0 0;
  // position: relative;
`;

export const CardImg = styled.img`
  // position: absolute;
  // top: 0;
  // left: 0;
  // width: 100%;
  // height: 100%;
  // display: block;
`;

export const CardFooter = styled.div`

`;

export const CardFooterTitle = styled.h5`

`;

export const ViewButton = styled.button`

`;
