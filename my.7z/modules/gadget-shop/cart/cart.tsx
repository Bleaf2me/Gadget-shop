import React from 'react'

export const ShoppingCart = () => {

  return (
    <div className="shopping-cart-table">
      <h2>Your Order</h2>
      <table className="table">
        <thead>
          <tr>
            <th>#</th>
            <th>Item</th>
            <th>Count</th>
            <th>Price</th>
            <th>Action</th>
          </tr>
        </thead>

        <tbody>

        </tbody>
      </table>

      <div className="total">
        Total: $100
      </div>
    </div>
  );
};